import io
import os
from datetime import datetime
import boto3
from botocore.exceptions import ClientError
from flask import Flask, flash, redirect, render_template_string, request, send_file, url_for
from moto import mock_aws
from werkzeug.utils import secure_filename

# Set fake AWS credentials locally so boto3 does not ask for real ones
os.environ["AWS_ACCESS_KEY_ID"] = "mock_key"
os.environ["AWS_SECRET_ACCESS_KEY"] = "mock_secret"
os.environ["AWS_DEFAULT_REGION"] = "ap-south-1"

# Start the local S3 simulation
mock = mock_aws()
mock.start()

BUCKET = "cloud-backup-gcet-2026"
s3 = boto3.client("s3", region_name="ap-south-1")

# Create local bucket with versioning enabled
s3.create_bucket(
    Bucket=BUCKET,
    CreateBucketConfiguration={"LocationConstraint": "ap-south-1"}
)
s3.put_bucket_versioning(
    Bucket=BUCKET,
    VersioningConfiguration={"Status": "Enabled"}
)

app = Flask(__name__)
app.secret_key = "cloud-backup-secret-key"

PAGE = """<!doctype html>
<html>
<head>
  <title>Cloud Backup & Disaster Recovery System</title>
  <style>
    body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; margin: 30px auto; max-width: 800px; background-color: #f4f6f9; color: #333; }
    h2 { color: #0d47a1; text-align: center; }
    .status-badge { display: inline-block; background-color: #e8f5e9; color: #2e7d32; font-size: 13px; padding: 4px 10px; border-radius: 12px; font-weight: bold; }
    .card { background: white; padding: 25px; border-radius: 8px; box-shadow: 0 4px 6px rgba(0,0,0,0.08); margin-bottom: 25px; }
    .btn { background: #1976d2; color: white; padding: 8px 16px; border: none; border-radius: 4px; cursor: pointer; text-decoration: none; font-weight: 500; }
    .btn:hover { background: #1565c0; }
    .msg { padding: 12px; background: #e3f2fd; color: #0d47a1; border-left: 5px solid #1976d2; border-radius: 4px; margin-bottom: 20px; font-weight: bold; }
    table { width: 100%; border-collapse: collapse; margin-top: 15px; }
    th, td { text-align: left; padding: 12px; border-bottom: 1px solid #ddd; }
    th { background-color: #f5f5f5; color: #444; }
  </style>
</head>
<body>
  <h2>Cloud Backup and Disaster Recovery System</h2>
  <p style="text-align:center;">
    <span class="status-badge">● S3 Storage Online: {{ bucket_name }}</span>
    <span class="status-badge">● Versioning: Enabled</span>
  </p>

  {% for m in get_flashed_messages() %}
    <div class="msg">{{ m }}</div>
  {% endfor %}

  <div class="card">
    <h3>Backup Module (Upload File to Cloud)</h3>
    <p style="color:#666; font-size: 14px;">Select an important document to create an automated off-site cloud backup.</p>
    <form method="post" action="/backup" enctype="multipart/form-data">
      <input type="file" name="file" required style="padding: 6px;">
      <button type="submit" class="btn">Backup File</button>
    </form>
  </div>

  <div class="card">
    <h3>Recovery Module (Disaster Recovery Backups)</h3>
    {% if files %}
    <table>
      <thead>
        <tr>
          <th>Backup Key / File Name</th>
          <th>Size</th>
          <th>Last Modified</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        {% for f in files %}
        <tr>
          <td><b>{{ f.Key }}</b></td>
          <td>{{ f.Size }} bytes</td>
          <td>{{ f.LastModified.strftime('%d-%m-%Y %H:%M') }}</td>
          <td><a class="btn" href="/restore/{{ f.Key }}">Restore</a></td>
        </tr>
        {% endfor %}
      </tbody>
    </table>
    {% else %}
      <p style="color:#777;">No backups found in cloud storage. Upload a file above to initiate backup.</p>
    {% endif %}
  </div>
</body>
</html>"""

@app.route("/")
def index():
    try:
        response = s3.list_objects_v2(Bucket=BUCKET)
        files = response.get("Contents", [])
    except ClientError as e:
        files = []
        flash("Cloud storage unavailable: " + str(e))
    return render_template_string(PAGE, files=files, bucket_name=BUCKET)

@app.route("/backup", methods=["POST"])
def backup():
    f = request.files.get("file")
    if not f or f.filename == "":
        flash("Invalid file selection")
        return redirect(url_for("index"))

    filename = secure_filename(f.filename)
    try:
        s3.upload_fileobj(f, BUCKET, filename)
        flash(f"Backup Successful: '{filename}' transferred to S3 bucket '{BUCKET}'")
    except ClientError as e:
        flash("Upload failed: " + str(e))
    return redirect(url_for("index"))

@app.route("/restore/<path:key>")
def restore(key):
    try:
        obj = s3.get_object(Bucket=BUCKET, Key=key)
        return send_file(
            io.BytesIO(obj["Body"].read()),
            download_name=key,
            as_attachment=True
        )
    except ClientError:
        flash("Backup file not found in storage")
        return redirect(url_for("index"))

if __name__ == "__main__":
    app.run(debug=True)